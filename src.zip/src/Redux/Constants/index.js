export default BASEURLS = {
  MainUrl: 'https://ekyatraterapanth.com/gpl/index.php/api/',
};
//https://demo.webshowcase-india.com/abtyp/