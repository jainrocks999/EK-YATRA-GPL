export default {
  pinckColor:'#8f3d61',
  white:'#fff',
  black:'#000',
  red:'#ed2225'
};
