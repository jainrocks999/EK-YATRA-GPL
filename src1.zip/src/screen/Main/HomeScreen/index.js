import React,{useEffect} from 'react';
import { View,Text,Image, TouchableOpacity,ImageBackground } from 'react-native';
import BottomTab from '../../../component/StoreButtomTab';
import styles from './styles';
import StatusBar from '../../../component/StatusBar';
import { useNavigation } from '@react-navigation/native';
import Header from '../../../component/header';
import Lang from '../../../component/language';
import { useDispatch } from 'react-redux';
import AsyncStorage from '@react-native-community/async-storage';
import Storage from '../../../component/AsyncStorage';
import { useState } from 'react';

let mob
const Home=()=>{
  const navigation=useNavigation()
  const dispatch=useDispatch()
  const [mobile,setMobile]=useState('')
  useEffect(async()=>{
    const user_id=await AsyncStorage.getItem(Storage.userid)
     mob=await AsyncStorage.getItem(Storage.mobile)
      setMobile(mob)
    // dispatch({
    //     type: 'Category_List_Request',
    //     url: 'getquiz',
    //   })
      dispatch({
        type: 'Leader_Board_Request',
        url: 'leaderboard1',
      })
     
   },[])
    const call = async() => {
      let number = await AsyncStorage.getItem(Storage.mobile);
      if(number==null){
        navigation.navigate('Login')
      }
      else{
        navigation.navigate('Category')
      }
    }
    return(
         <View style={styles.container}>
          <Header
          source={require('../../../assets/Images/bell.png')}
           title={Lang.Home}/>
            <View style={styles.imageCont}>
               <Image style={styles.logo} 
               source={require('../../../assets/Images/logo.jpg')}/>
           </View>
         <View style={styles.second}>
          <TouchableOpacity
          onPress={()=>navigation.navigate('About')}
          style={styles.card}>
             <Image style={styles.icon} 
             source={require('../../../assets/Images/about-img.png')}/>
            <Text style={styles.text}>{Lang.AboutApp}</Text>
          </TouchableOpacity>

          <TouchableOpacity
          onPress={()=>navigation.navigate('Book')}
           style={[styles.card,{marginTop:10}]}>
              <Image style={styles.icon} 
              source={require('../../../assets/Images/book-img.png')}/>
            <Text style={styles.text}>{Lang.Ebook}</Text>
          </TouchableOpacity>

          <TouchableOpacity
           onPress={()=> call()}
           style={[styles.card,{marginTop:10}]}>
              <Image style={styles.icon} 
              source={require('../../../assets/Images/quiz1.png')}/>
            <Text style={styles.text}>{'Play Quiz'}</Text>
          </TouchableOpacity>
         </View>
         <StatusBar/>
         <BottomTab
         mobile={mobile}
         />
       </View>
    )
}
export default Home;