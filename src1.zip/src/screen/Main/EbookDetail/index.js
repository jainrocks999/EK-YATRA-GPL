import React from 'react';
import { View,Text ,Image,TouchableOpacity} from 'react-native';
import styles from './styles';
import StatusBar from '../../../component/StatusBar';
import Pdf from 'react-native-pdf';
import colors from '../../../component/colors';
import { useNavigation } from '@react-navigation/native';
import { WebView } from 'react-native-webview';


const EbookDetail = ({route}) => {
          const data1=route.params
          const navigation=useNavigation()
          const source = Platform.OS === 'android' ? { uri: "bundle-assets://pdf/terapanth_ka_itihaas_part_1.pdf" } : { uri: "bundle-assets://terapanth_ka_itihaas_part_1.pdf" }
          return (
            <View style={styles.container}>
              <View style={[styles.main, { backgroundColor: colors.pinckColor, }]}>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                  <Image style={styles.image}
                    source={require('../../../assets/Images/arrow1.png')} />
                </TouchableOpacity>
                <View style={{alignItems:'center'}}>
                  <Text style={{
                    color: 'white',
                    fontSize: 18,
                    fontFamily: 'Poppins-SemiBold',
                    alignSelf:'center'
                  }}>{data1.title}</Text>
                </View>
                <View></View>
              </View>
              <View style={styles.second}>
                <View style={styles.main1}>
                  <Pdf
                    source={source}
                    onLoadComplete={(numberOfPages, filePath) => {
                      console.log(`number of pages: ${numberOfPages}`);
                    }}
                    onError={(error) => {
                      console.log(error);
                    }}
                    style={styles.pdf}
                  />
                </View>
              </View>
              <StatusBar />
            </View>
  )
}
export default EbookDetail;