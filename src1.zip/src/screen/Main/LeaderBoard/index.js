import React,{useEffect,useState} from 'react';
import { View,Text,Image,FlatList } from 'react-native';
import BottomTab from '../../../component/StoreButtomTab';
import styles from './style';
import StatusBar from '../../../component/StatusBar';
import Header from '../../../component/header';
import { useSelector } from 'react-redux';
import AsyncStorage from '@react-native-community/async-storage';
import Storage from '../../../component/AsyncStorage';

const Leader=()=>{
  const [mobile,setMobile]=useState();
  let selector=useSelector(state=>state.LeaderBoard);

  useEffect(async()=>{
   let mobile=await AsyncStorage.getItem(Storage.mobile)
    setMobile(mobile)
 },[])

 const showList=()=>{
   if(selector.length){
     return(
      <View style={{flex:1}}>
      <FlatList
      style={{marginBottom:57}}
      data={selector}
      renderItem={({item})=>(
        <View style={styles.card}>
          <View style={{flexDirection:'row'}}>
          <Text style={[styles.name,{width:'38%'}]}>Name :</Text>
          <Text style={[styles.name,{width:'57%'}]}>{`${item.name}`}</Text>
          </View>
          {/* <View style={{flexDirection:'row'}}>
          <Text style={[styles.name,{width:'38%'}]}>Time :</Text>
          <Text style={[styles.name,{width:'57%'}]}>{`${Math.floor(item.time_taken / 60)} min : ${item.time_taken % 60} sec`}</Text>
          </View>  */}
         
          <View style={{flexDirection:'row'}}>
          <Text style={[styles.name,{width:'38%'}]}>Total Score :</Text>
          <Text style={[styles.name,{width:'57%'}]}>{item.no_of_correct}</Text>
          </View>
          <View style={{flexDirection:'row'}}>
          <Text style={[styles.name,{width:'38%'}]}>Area :</Text>
          <Text style={[styles.name,{width:'57%'}]}>{item.area}</Text>
          </View>
          <View style={{flexDirection:'row'}}>
          <Text style={[styles.name,{width:'38%'}]}>City :</Text>
          <Text style={[styles.name,{width:'57%'}]}>{item.city}</Text>
          </View>
         
        </View>
      )}
      />
     </View>
     )
   }
   else{
     return(
       <View style={styles.image}>
         <Image source={require('../../../assets/Images/dummy.jpg')}/>
       </View>
     )
   }
 }
    return(
         <View style={styles.container}>
           <Header
           title='Leader Board'
           />
          {showList()}
         <StatusBar/>
         <View style={styles.bottom}>
         <BottomTab
         mobile={mobile}
         />
         </View>
       </View>
    )
}
export default Leader;