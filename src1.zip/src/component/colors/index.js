export default {
  pinckColor:'#8f3d61',
  white:'#fff',
  black:'#000'
};
