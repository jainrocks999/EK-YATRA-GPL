export default {
    userid:'userid',
    email:'email',
    mobile:'mobile',
    name:'name',
    roundname:'roundname',
    commonQuizId:'commonQuizId',
    Token:'Token',
    correctCount:'correctCount',
    taken_time:'taken_time',
    total_attempts:'total_attempts',
    attempArrat:'attempArrat',
}