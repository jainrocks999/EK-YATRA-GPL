export default BASEURLS = {
  MainUrl: 'https://ekyatraterapanth.com/adminpanel/index.php/api/',
};
//https://demo.webshowcase-india.com/abtyp/